function UploadButton_onclick(){
	var Pipeline_Step_id=getValue('Pipeline_Step_id');
	var upload_type=getValue('UploadType');
    if(upload_type==0){
        alert("Please Select the type of upload from the dropdown");
        return;
    }

    if(Pipeline_Step_id!=0)
    {
        if(upload_type=='Single File'){
            var file = getValue('PipelineFile');
			$.blockUI({message: 'Starting upload of file'});
			UploadPipelineFile.uploadSingleFile(Pipeline_Step_id,file,function(data) {
				$.unblockUI();
				setReloadGrid('PipelineloadingGrid');
				$.blockUI({message: data});
				setTimeout($.unblockUI, 1000);
			});
		}
        else if (upload_type=='Zip File') {
			var file = getValue('PipelineFile');
			$.blockUI({message: 'Starting upload of files'});
			UploadPipelineFile.uploadZipFile(Pipeline_Step_id,file,function(data) {
				setReloadGrid('PipelineloadingGrid');
				$.blockUI({message: data});
				setTimeout($.unblockUI, 1000);
			});
		}
		else if (upload_type=='Local Directory') {
			var local_directory_name = getValue('local_directory_name');
			IterateThroughLocalDirectory(local_directory_name);
		}
		else 
			alert("Invalid upload type");   //Should not happen
	}
    else{
		alert("Please Select a pipeline from the dropdown above");
	}  
}
function DownloadButton_onclick(){
	var Pipeline_Step_id=getValue('Pipeline_Step_id');
	if(Pipeline_Step_id!=0){
		var processing_pipeline_step_id=getIdOfSelectedRow('PipelineloadingGrid');
		if(processing_pipeline_step_id==null) {
			alert("Please select a pipeline file from the grid above");
			return;
		}
		$.blockUI({message: 'Starting download of pipeline file'});
		UploadPipelineFile.downloadPipelineFile(processing_pipeline_step_id,function(data) {
				$.unblockUI();
				if(data)
				{
					window.open(data);
				}
		});
	}
	else {
		alert("Please Select a pipeline from the dropdown above");
		return;
	}
}
function DeleteAllButton_onclick(){
	var Pipeline_Step_id=getValue('Pipeline_Step_id');
	if(Pipeline_Step_id!=0){
		var processing_pipeline_step_id=getIdOfSelectedRow('PipelineloadingGrid');
		if(processing_pipeline_step_id==null) {
			alert("Please select a pipeline file from the grid above");
			return;
		}
		if (confirm("Corpus file elements will be deleted! Do you want to coninue?")) {
			$.blockUI({message: 'Starting deletion of pipeline file elements'});
			UploadCorpusFile.deleteAllCorpusFileElements(processing_pipeline_step_id,function(data) {
				$.unblockUI();
				setReloadGrid('PipelineloadingGrid');
				$.blockUI({message: data});
				setTimeout($.unblockUI, 1000);
			});
		}
	}
	else {
		alert("Please Select a pipeline from the dropdown above");
		return;
	}
}

function IterateThroughLocalDirectory(local_directory_name){

}